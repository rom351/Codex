LOW-POLY GAME PROP PACK
============================================================

12 stylized low-poly 3D models, 1,228 triangles in total.

CONTENTS
------------------------------------------------------------
blend/  one .blend file with all 12 models (each model in its own collection)
fbx/    one .fbx file per model
obj/    one .obj (+ .mtl) file per model

MODELS (size in Blender units, 1 unit = 1 meter: X x Y x Z)
------------------------------------------------------------
- Wooden Crate      108 tris   1.02 x 1.02 x 1.0   (wooden_crate)
- Barrel            168 tris   0.91 x 0.91 x 0.91   (barrel)
- Treasure Chest    132 tris   0.9 x 0.66 x 0.72   (treasure_chest)
- Pine Tree          50 tris   0.87 x 1.0 x 1.63   (pine_tree)
- Round Tree         80 tris   1.08 x 0.93 x 1.48   (round_tree)
- Rock Cluster       60 tris   1.23 x 0.85 x 0.53   (rock_cluster)
- Mushroom          116 tris   0.7 x 0.7 x 0.52   (mushroom)
- Sword              70 tris   0.34 x 0.09 x 1.06   (sword)
- Potion Bottle      76 tris   0.3 x 0.29 x 0.54   (potion_bottle)
- Lantern           124 tris   0.26 x 0.26 x 0.59   (lantern)
- Fence Section      48 tris   1.22 x 0.12 x 0.8   (fence_section)
- Campfire          196 tris   1.02 x 0.91 x 0.51   (campfire)

NOTES
------------------------------------------------------------
- Every model has its origin at the center of its base, standing on Z = 0.
- Flat shading, simple solid-color materials, no textures and no UV maps.
- FBX and OBJ files were exported from Blender with its default axis settings.
- All files were re-imported into Blender after export to check that they open correctly.

TERMS
------------------------------------------------------------
- You may use these models in personal and commercial projects (games, apps, videos, renders).
- Please do not resell, share or redistribute the model files themselves, alone or in another pack.
- Provided as is, without warranty.
